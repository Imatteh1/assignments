const express = require('express');
const app = express(); 
const bodyParser = require('body-parser');
const multer = require('multer');
const upload = multer();
const hbs = require('hbs');
const path=require("path");
const formidable=require('formidable');
const mongoose = require('mongoose');

var url = 'mongodb://127.0.0.1/Assignment';
mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true });

//Get the default connection
console.log("DB Connected");
var db = mongoose.connection;

//Bind connection to error event (to get notification of connection errors)
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

app.set('view engine','hbs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false })); 

var productSchema = mongoose.Schema(
	{
		name: String,
		description: String,
		category: String, 
		price: Number, 
		review: String
	});
 var Product = mongoose.model("Product", productSchema);

 var userSchema = mongoose.Schema(
	{
		username: String,
		password: String,
		type: String
	}); 
var User = mongoose.model("User", userSchema);

app.get('/', function(req,res){
	res.sendFile(__dirname + '/register.html');
});
app.post('/register', function(req, res){
	var user = req.body;

	var newUser = new User({username:user.name, password: user.password, type: user.type});
	newUser.save(function(err, User){
		if (err) throw err;
		console.log(User);
	});

	if(user.type == "buyer") res.redirect('/buyer');
	else if(user.type == "seller") res.redirect('/seller');
});

app.get('/', function(req,res){
		res.sendFile(__dirname + '/login.html');
});
app.post('/log', function(req, res){
	var userData = req.body;

	User.find({username:userData.name, password: userData.password}, function(err, result){
		if(result[0].type == "buyer")
			res.redirect('/buyer');
		else if(result[0].type == "seller")
			res.redirect('/seller');
	});
});

app.use('/assets',express.static(__dirname + '/public'));
app.get('/buyer', function(req,res){
	Product.find(function(err, r){
		res.render('buyer',{result: r});
	});
});

app.get('/seller', function(req,res){
	Product.find(function(err, doc){
		res.render('seller',{results: doc});
	});
});

app.post('/save',function(req,res){
 console.log("Data recieved");
 console.log(req.body);
 var productInfo = req.body;


 var newProduct = new Product({ name: productInfo.product_name, description: productInfo.product_desc, category: productInfo.product_category, price: productInfo.product_price, review: productInfo.product_review  }); 
		newProduct.save(function(err, Product){ 
		if(err) console.log(err);
		console.log("Data added!");
		res.redirect("/seller");
	}); 
});

app.post('/delete', function(req,res){
	var item = req.body;
	Product.findByIdAndRemove(item.product_id, function(err, response){
	 if(err) console.log(err);
	 res.redirect("/seller");
	  }); 
});
		
app.post('/update', function(req,res){
	var productInfo = req.body;
	console.log(req.body);
	Product.findOneAndUpdate({id: req.body.product_id},{ name: productInfo.product_name, desc: productInfo.product_desc, category: productInfo.product_category, price: productInfo.product_price, review: productInfo.product_review  },function(err, response){
	 if(err) console.log(err);
	 res.redirect("/seller");
	  }); 
});
app.all('*',function(req,res){
	res.send("Invalid Request");
})
app.listen(8000);
/*
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(upload.array());

app.get('/signup', function(req,res){
	res.render('signup',
			{
				user:{
					username:"root",
					password:"root"	
				}
			});
	});

/*app.get('/buyer', function(req,res){
	res.render('buyer',
			{
				user:{
					username:"root",
					password:"root"
				}
			});

});

var userSchema = mongoose.Schema(
	{
		username: String,
		password: String,
		type: String
	}); 
var User = mongoose.model("Users", userSchema);


app.post('/signup', function(req, res){
	var userData = req.body;
	//console.log(userData);
	var newUser = new User(
		{
			username: userData.name, 
			password: userData.pwd, 
			type: userData.type
		});
	newUser.save(function(err, User){
		if (err) throw err;
		else{
			console.log(newUser);
		}
		    console.log(newUser);
    		res.send("User Added!");
	});

});

app.get('/index', function(req,res){
		res.render('index',
			{
				user:{
					username:"root",
					password:"root"
				}
			});
	});

var productSchema = mongoose.Schema(
	{
		id: Number, 
		name: String, 
		price: String 
	}); 
var Product = mongoose.model("Products", productSchema);

app.post('/addNew', function(req, res){
    //console.log("Request Recieved!!");
    var productData = req.body;
    console.log(productData);
    if(!productData.id||!productData.name||!productData.price)
    	console.log("Data Invalid"); 
    else{
    	var newProduct = new Product(
    		{
    			id:productData.id, 
    			name:productData.name, 
    			price:productData.price
    		});
    	newProduct.save(function(err, Product){
    		if (err) throw err;
    		else {
    			console.log("Data saved in Database");
    		}
    		console.log(newProduct);
    		res.send("Product Added!");
    	});
    }
});

app.get('/login', function(req,res){
	res.render('login',
			{
				user:{
					username:"root",
					password:"root"
				}
			});
	});

app.post('/login', function(req, res){
	var login_user = req.body;
	if(!login_user.name || !login_user.pwd){
		res.render('login', {message: "Please enter both id and password"});
	} 
	else {
   	
  		User.find({username: login_user.name, password: login_user.pwd}, function(err, result){
  			if(err) throw err;
  			else{
  				console.log(result);
  				result.filter(function(user){
         			if(user.type == 'buyer'){
            			//req.session.user = user;
            			//console.log(user.username);
            			Product.find(function(err, Presult){
            				Presult.filter(function(product){
            					//console.log(Presult);
            					app.get('/buyer', function(req,res){
            						var products = [];
            						for(var i = 0; i < Presult.length; i++){
            							products.push(Presult.slice(i, i +1));
            						}
									res.render('buyer',
									{
										result:
										{
											name:user.username,
											type:user.type,
											product: products,
											length: products.length
										}
									});
								});
							});
            			});		
            			res.redirect('/buyer');
         			}
         		console.log(user.type);
      		});
  		}
   		//console.log(res.json(result));
   		//var auth = JSON.parse(result);

   		//console.log(auth.type);
	});
  }
});

app.listen(8000);*/